import { DataSourceOptions } from 'typeorm';
import { ConfigService } from '@nestjs/config';

export const getTypeOrmConfig = (configService: ConfigService): DataSourceOptions => {
  console.log(__dirname + '/../../../**/**/entities/*.entity.{ts,js}');

  return {
    type: 'postgres',
    url: configService.get<string>('DATABASE_URL'),
    entities: [
      __dirname + '/../../services/**/modules/**/model/*.entity.{ts,js}',
      __dirname + '/../../services/taxes-ms/providers/**/*.entity.{ts,js}',
    ],
    synchronize: false, // true solo en desarrollo, cuidado en prod
    logging: true,
  };
};
