import { Test, TestingModule } from '@nestjs/testing';
import { PasswordController } from './password.controller';
import { UserService } from '../../user/services/user.service';
import { TokenService } from '../../token/services/token.service';
import { EmailVerificationService } from '../../../../email-ms/services/verification.service';
import { PasswordService } from '../services/password.service';
import { NotFoundException, BadRequestException } from '@nestjs/common';

describe('PasswordController', () => {
  let controller: PasswordController;

  const user = {
    id: 'user-1',
    email: 'test@example.com',
    password_hash: 'hashed',
    updated_at: new Date(),
    is_email_verified: true,
  };

  const mockToken = {
    token: {
      user: { id: user.id },
      expires_at: new Date(Date.now() + 3600 * 1000),
    },
  };

  const userService = {
    findByEmail: jest.fn(),
    findById: jest.fn(),
    updateUser: jest.fn(),
    toResponse: jest.fn().mockReturnValue({ id: user.id }),
  };

  const tokenService = {
    generateToken: jest.fn(),
  };

  const emailVerificationService = {
    createVerificationTokenEmail: jest.fn(),
    getEmailVerificationToken: jest.fn(),
    deleteToken: jest.fn(),
  };

  const passwordService = {
    hashPassword: jest.fn(),
    checkPassword: jest.fn(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [PasswordController],
      providers: [
        { provide: UserService, useValue: userService },
        { provide: TokenService, useValue: tokenService },
        { provide: EmailVerificationService, useValue: emailVerificationService },
        { provide: PasswordService, useValue: passwordService },
      ],
    }).compile();

    controller = module.get(PasswordController);
    jest.clearAllMocks();
  });

  describe('forgotPassword', () => {
    it('should send reset token if user exists', async () => {
      userService.findByEmail.mockResolvedValue(user);
      tokenService.generateToken.mockResolvedValue('reset-token');
      emailVerificationService.createVerificationTokenEmail.mockResolvedValue({
        token: 'reset-token',
      });

      const result = await controller.forgotPassword(user.email);

      expect(result).toEqual({
        message: 'Password reset email sent successfully',
        user: { id: user.id },
      });
    });

    it('should throw NotFoundException if user not found', async () => {
      userService.findByEmail.mockResolvedValue(null);
      await expect(controller.forgotPassword('invalid@example.com')).rejects.toThrow(
        NotFoundException,
      );
    });
  });

  describe('resetPassword', () => {
    const req = { user: { sub: user.id } };

    it('should reset password if token is valid', async () => {
      userService.findById.mockResolvedValue(user);
      emailVerificationService.getEmailVerificationToken.mockResolvedValue(mockToken);
      passwordService.hashPassword.mockResolvedValue('newhash');
      userService.updateUser.mockResolvedValue({ ...user, password_hash: 'newhash' });

      const result = await controller.resetPassword(req, 'valid-token', 'new-password');

      expect(result).toEqual({
        message: 'Password reset successfully',
        user: { id: user.id },
      });
    });

    it('should throw NotFoundException if user not found', async () => {
      userService.findById.mockResolvedValue(null);
      await expect(controller.resetPassword(req, 'token', 'pass')).rejects.toThrow(
        NotFoundException,
      );
    });

    it('should throw NotFoundException if token is invalid', async () => {
      userService.findById.mockResolvedValue(user);
      emailVerificationService.getEmailVerificationToken.mockResolvedValue({ token: null });
      await expect(controller.resetPassword(req, 'invalid-token', 'pass')).rejects.toThrow(
        NotFoundException,
      );
    });

    it('should throw NotFoundException if token is expired', async () => {
      userService.findById.mockResolvedValue(user);
      emailVerificationService.getEmailVerificationToken.mockResolvedValue({
        token: { ...mockToken.token, expires_at: new Date(Date.now() - 1000) },
      });
      await expect(controller.resetPassword(req, 'expired-token', 'pass')).rejects.toThrow(
        NotFoundException,
      );
    });
  });

  describe('changePassword', () => {
    const req = { user: { sub: user.id } };

    it('should change password if current one is correct', async () => {
      userService.findById.mockResolvedValue(user);
      passwordService.checkPassword.mockResolvedValue(true);
      passwordService.hashPassword.mockResolvedValue('newhash');
      userService.updateUser.mockResolvedValue({ ...user, password_hash: 'newhash' });

      const result = await controller.changePassword(req, 'old-password', 'new-password');

      expect(result).toEqual({
        message: 'Password changed successfully',
        user: { id: user.id },
      });
    });

    it('should throw NotFoundException if user not found', async () => {
      userService.findById.mockResolvedValue(null);
      await expect(controller.changePassword(req, 'old', 'new')).rejects.toThrow(NotFoundException);
    });

    it('should throw BadRequest if old password is incorrect', async () => {
      userService.findById.mockResolvedValue(user);
      passwordService.checkPassword.mockResolvedValue(false);
      await expect(controller.changePassword(req, 'wrong-old', 'new')).rejects.toThrow(
        BadRequestException,
      );
    });
  });
});
