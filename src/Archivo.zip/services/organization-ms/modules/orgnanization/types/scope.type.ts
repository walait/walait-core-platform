export type ScopeType = 'global' | 'organization' | 'app';
