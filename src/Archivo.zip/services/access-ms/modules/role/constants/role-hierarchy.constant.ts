export const RoleHierarchy = {
  member: 1,
  admin: 2,
  owner: 3,
  superadmin: 4,
};
