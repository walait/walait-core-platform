import { Module } from '@nestjs/common';
import { TAX_PROVIDERS } from '../../taxes.const';
import { ArTaxesProvider } from './ar-taxes.provider';
import { AfipAuthModule } from './afip/auth/afip-auth.module';

@Module({
  imports: [AfipAuthModule],
  providers: [
    ArTaxesProvider,
    {
      provide: TAX_PROVIDERS,
      useExisting: ArTaxesProvider,
    },
  ],
  exports: [TAX_PROVIDERS],
})
export class ArTaxesModule {}
