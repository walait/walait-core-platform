export enum TiposAlicuotaIva {
  Iva21 = '21%',
  Iva10_5 = '10.5%',
}
