export const Monedas = {
  peso_arg: {
    id: 'PES',
    valor: 1,
  },
} as const;
