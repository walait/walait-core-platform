export enum TiposComprobantes {
  invoiceA = 'A',
  invoiceB = 'B',
  invoiceC = 'C',
  invoiceM = 'M',
  UsedGoods = 'BienesUsados',
}
