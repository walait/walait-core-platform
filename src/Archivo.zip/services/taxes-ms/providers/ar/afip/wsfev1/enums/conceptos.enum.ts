export enum Conceptos {
  Producto = 1,
  Servicio = 2,
  ProductoYServicio = 3,
}
