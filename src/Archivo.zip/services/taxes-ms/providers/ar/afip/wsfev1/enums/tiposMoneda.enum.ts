export enum MonedasArgentinas {
  PESO = 'peso_arg',
  DOLAR = 'usd_arg',
}
