export const Consumers = {
  B: {
    ivaSujExe: 4,
    consumidorFinal: 5,
    sujetoNoCategorizado: 7,
    proveedorDelExterior: 8,
    clienteDelExterior: 9,
    ivaLiberadoLey19640: 10,
    ivaNoAlcanzado: 15,
  },
  A: {
    ivaResponsableInscripto: 1,
    responsableMonotributo: 6,
    monotributistaSocial: 13,
    monotributoTrabajadorIndependientePromovido: 16,
  },
};
