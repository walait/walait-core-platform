export const AlicIva = {
  '21%': {
    id: 5,
    baseImp: 100,
    importe: 21,
  },
  '10.5%': {
    id: 4,
    baseImp: 50,
    importe: 5.25,
  },
};
