import { Module } from '@nestjs/common';
import { WsaaService } from './service/wsaa.service';
import { TicketBuilder } from './builder/ticket.builder';
import { TicketSigner } from './signer/ticket.signer';
import { WsaaSoapClient } from './wsaa.client';
import { TokenStore } from './store/token.store';
import { SharedModule } from '@/shared/shared.module';
import { PkiModule } from '../cert/modules/pki/pki.module';
import { WsaaController } from './controller/wsaa.controller';

@Module({
  providers: [WsaaService, TicketBuilder, TicketSigner, WsaaSoapClient, TokenStore],
  imports: [
    SharedModule,
    PkiModule.register({
      opensslPath: '/opt/homebrew/bin/openssl',
      keySize: 4096,
    }),
  ], // ✅ agregá esto
  exports: [WsaaService, WsaaSoapClient],
  controllers: [WsaaController],
})
export class WsaaModule {}
