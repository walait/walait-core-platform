import {
  Body,
  ConflictException,
  Controller,
  Delete,
  Get,
  NotFoundException,
  Param,
  Put,
  Req,
  UseGuards,
  UsePipes,
} from '@nestjs/common';
import { ZodValidationPipe } from 'nestjs-zod';

import { JwtAuthGuard } from '@/services/identity-ms/guards/jwt.guard';
import { UserService } from '../identity-ms/modules/user/services/user.service';
import { PermissionService } from '@/services/access-ms/modules/permission/services/permission.service';
import { Role } from '@/services/access-ms/modules/role/models/role.entity';
import { Roles } from '@/services/access-ms/decorator/role.decorator';
import { Request } from 'express';
import { IUserRequest } from '@/services/identity-ms/modules/user/models/user.interface';
import { RoleHierarchy } from '@/services/access-ms/modules/role/constants/role-hierarchy.constant';
import { OrganizationService } from '../organization-ms/modules/orgnanization/services/organization.service';

@UsePipes(ZodValidationPipe)
@Controller('admin')
export class AdminController {
  constructor(
    private readonly userService: UserService,
    private readonly organizationService: OrganizationService,
  ) {}

  @Roles('admin')
  @UseGuards(JwtAuthGuard)
  @Get('users')
  async getUsersAdmin(@Req() req: Request & { user: IUserRequest }) {
    const organizationId = req.user.organization_id;

    const users = await this.userService.findAll();
    const mapped: { roleName: string; organization_id: string }[] = [];
    for (const { userRoles, ...rest } of users) {
      const currentHierarchy = RoleHierarchy[req.user.role];
      const userRole = userRoles.find((role) => role.organization_id === organizationId);
      const organization = await this.organizationService.getOrganizationById(organizationId);

      const base = {
        organization_id: organization.id,
        organizationName: organization.name,
      };
      if (currentHierarchy === 4) {
        const anyRole = userRole ?? userRoles[0];
        mapped.push({
          ...rest,
          ...base,
          roleName: anyRole?.role?.name,
        });
      }

      mapped.push({
        ...rest,
        ...base,
        roleName: userRole.role?.name,
      });
    }

    return mapped.filter((user) => {
      if (!user) return false;

      const currentHierarchy = RoleHierarchy[req.user.role];
      const userHierarchy = RoleHierarchy[user.roleName];

      if (currentHierarchy === 4) {
        return true;
      }

      return currentHierarchy >= userHierarchy && user.organization_id === organizationId;
    });
  }
}
