import { Module } from '@nestjs/common';
import { PermissionService } from './modules/permission/services/permission.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserRole } from './modules/user-roles/models/user-role.entity';
import { Role } from './modules/role/models/role.entity';
import { Permission } from './modules/permission/models/permission.entity';
import { RolePermission } from './modules/role-permission/models/role-permission.entity';
import { APP_GUARD } from '@nestjs/core/constants';
import { PermissionsGuard } from './modules/permission/guards/permission.guard';
import { RolesGuard } from './modules/permission/guards/role.guard';
import { UserRoleService } from './modules/user-roles/services/user-role.service';
import { RoleService } from './modules/role/services/role.service';
import { AccessService } from './services/access.service';

@Module({
  imports: [TypeOrmModule.forFeature([UserRole, Role, Permission, RolePermission])],
  providers: [
    PermissionService,
    {
      provide: APP_GUARD,
      useClass: RolesGuard,
    },
    {
      provide: APP_GUARD,
      useClass: PermissionsGuard,
    },
    UserRoleService,
    RoleService,
    AccessService,
  ],
  exports: [PermissionService, UserRoleService, RoleService, AccessService],
})
export class AccessModule {}
