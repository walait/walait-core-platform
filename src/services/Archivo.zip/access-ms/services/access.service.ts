import { Injectable } from '@nestjs/common';
import { RoleService } from '../modules/role/services/role.service';
import { UserRoleService } from '../modules/user-roles/services/user-role.service';
import { User } from '@/services/identity-ms/modules/user/models/user.entity';
import { Membership } from '@/services/organization-ms/modules/membership/models/membership.entity';
import { Organization } from '@/services/organization-ms/modules/orgnanization/models/organization.entity';
import { UserRole } from '../modules/user-roles/models/user-role.entity';
import { EntityManager } from 'typeorm';

@Injectable()
export class AccessService {
  // Add your service methods here
  constructor(private readonly userRoleService: UserRoleService) {}

  async assignInitialRole(
    isGlobalAdmin: boolean,
    user: User,
    membership: Membership,
    organization: Organization,
    manager?: EntityManager,
  ): Promise<UserRole> {
    if (!isGlobalAdmin) {
      return this.userRoleService.createUserRole(
        user,
        membership.role,
        'organization',
        organization,
        manager,
      );
    } else {
      const superadminRole = await this.userRoleService.getAdminRole('superadmin');

      return this.userRoleService.createUserRole(
        user,
        superadminRole.name,
        'global',
        organization,
        manager,
      );
    }
  }
}
