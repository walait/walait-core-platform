import { Entity, PrimaryGeneratedColumn, Column, RelationId, ManyToOne, OneToOne } from 'typeorm';
import { RolePermission } from '../../role-permission/models/role-permission.entity';
import { Role } from '../../role/models/role.entity';

@Entity('user_roles')
export class UserRole {
  @PrimaryGeneratedColumn('uuid')
  id: string;
  @Column() user_id: string; // ← viene de identity-ms
  @RelationId((rp: RolePermission) => rp.role)
  role_id: string; // ← Role.id

  @OneToOne(() => UserRole, (ur) => ur.role, { onDelete: 'CASCADE' })
  role: Role;

  @Column() organization_id: string; // ← viene de organization-ms
  @Column({ default: 'organization' }) scope: 'global' | 'organization' | 'app';
  @Column({ type: 'timestamptz', default: () => 'now()' }) granted_at: Date;
}
