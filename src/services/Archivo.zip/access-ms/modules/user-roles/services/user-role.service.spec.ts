import { Test, TestingModule } from '@nestjs/testing';
import { UserRoleService } from './user-role.service';
import { getRepositoryToken } from '@nestjs/typeorm';
import { UserRole } from '../models/user-role.entity';
import { Role } from '../../role/models/role.entity';
import { User } from '@/services/identity-ms/modules/user/models/user.entity';
import { Repository } from 'typeorm';
import { RoleService } from '../../role/services/role.service';
import { ConflictException, NotFoundException } from '@nestjs/common';
import { ScopeType } from '@/services/organization-ms/modules/orgnanization/types/scope.type';
import { Organization } from '@/services/organization-ms/modules/orgnanization/models/organization.entity';

describe('UserRoleService', () => {
  let service: UserRoleService;
  let repo: jest.Mocked<Repository<UserRole>>;
  let roleService: jest.Mocked<RoleService>;

  const user: User = { id: 'user-1' } as User;
  const role: Role = { id: 'role-1', name: 'admin' } as Role;
  const userRole: UserRole = {
    id: 'ur-1',
    user_id: 'user-123',
    role_id: 'role-1',
    role: null,
    scope: 'organization' as ScopeType,
    organization_id: '123',
  } as UserRole;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        UserRoleService,
        {
          provide: getRepositoryToken(UserRole),
          useValue: {
            create: jest.fn(),
            save: jest.fn(),
            find: jest.fn(),
            findOne: jest.fn(),
            remove: jest.fn(),
          },
        },
        {
          provide: RoleService,
          useValue: {
            getRoleByNameAndScope: jest.fn(),
          },
        },
      ],
    }).compile();

    service = module.get(UserRoleService);
    repo = module.get(getRepositoryToken(UserRole));
    roleService = module.get(RoleService);
    jest.clearAllMocks();
  });

  describe('createUserRole', () => {
    it('should create user role with Role instance', async () => {
      repo.create.mockReturnValue(userRole);
      repo.save.mockResolvedValue(userRole);
      roleService.getRoleByNameAndScope = jest.fn().mockResolvedValue(role);
      const result = await service.createUserRole(
        user,
        role,
        'organization' as ScopeType,
        {} as Organization,
      );

      expect(repo.create).toHaveBeenCalledWith({
        user,
        role,
        scope: 'organization' as ScopeType,
        organization: {},
      });
      expect(result).toEqual(userRole);
    });

    it('should resolve role by name and create user role', async () => {
      roleService.getRoleByNameAndScope.mockResolvedValue(role);
      repo.create.mockReturnValue(userRole);
      repo.save.mockResolvedValue(userRole);

      const result = await service.createUserRole(
        user,
        'admin',
        'organization' as ScopeType,
        {} as Organization,
      );

      expect(roleService.getRoleByNameAndScope).toHaveBeenCalledWith('admin', '123');
      expect(result).toEqual(userRole);
    });
  });

  describe('findByUserId', () => {
    it('should find roles by user ID', async () => {
      repo.find.mockResolvedValue([userRole]);
      const result = await service.findByUserId(user.id);
      expect(result).toEqual([userRole]);
    });
  });

  describe('findByRoleId', () => {
    it('should find roles by role ID', async () => {
      repo.find.mockResolvedValue([userRole]);
      const result = await service.findByRoleId(role.id);
      expect(result).toEqual([userRole]);
    });
  });

  describe('findByUserIdAndRoleId', () => {
    it('should find one user-role by user and role ID', async () => {
      repo.findOne.mockResolvedValue(userRole);
      const result = await service.findByUserIdAndRoleId(user.id, role.id);
      expect(result).toEqual(userRole);
    });
  });

  describe('assignRoleToUser', () => {
    it('should create and assign role to user', async () => {
      repo.create.mockReturnValue(userRole);
      repo.save.mockResolvedValue(userRole);

      const result = await service.assignRoleToUser(user.id, role.id);
      expect(result).toEqual(userRole);
    });
  });

  describe('removeRoleFromUser', () => {
    it('should remove role if found', async () => {
      repo.findOne.mockResolvedValue(userRole);
      await service.removeRoleFromUser(user.id, role.id);
      expect(repo.remove).toHaveBeenCalledWith(userRole);
    });

    it('should not call remove if user-role not found', async () => {
      repo.findOne.mockResolvedValue(null);
      await service.removeRoleFromUser(user.id, role.id);
      expect(repo.remove).not.toHaveBeenCalled();
    });
  });

  describe('getAllUserRoles', () => {
    it('should return all user roles', async () => {
      repo.find.mockResolvedValue([userRole]);
      const result = await service.getAllUserRoles();
      expect(result).toEqual([userRole]);
    });
  });

  describe('getUserRolesByUserId', () => {
    it('should return all roles for a user', async () => {
      repo.find.mockResolvedValue([userRole]);
      const result = await service.getUserRolesByUserId(user.id);
      expect(result).toEqual([userRole]);
    });
  });

  describe('assignRole', () => {
    it('should return existing role if already assigned', async () => {
      roleService.getRoleByNameAndScope.mockResolvedValue(role);
      repo.findOne.mockResolvedValue(userRole);

      const result = await service.assignRole(
        user,
        'admin',
        'organization' as ScopeType,
        {} as Organization,
      );
      expect(result).toEqual(userRole);
    });

    it('should create role assignment if not existing', async () => {
      roleService.getRoleByNameAndScope.mockResolvedValue(role);
      repo.findOne.mockResolvedValue(null);
      repo.create.mockReturnValue(userRole);
      repo.save.mockResolvedValue(userRole);

      const result = await service.assignRole(
        user,
        'admin',
        'organization' as ScopeType,
        {} as Organization,
      );
      expect(result).toEqual(userRole);
    });
  });

  describe('getAdminRole', () => {
    it('should return role if found', async () => {
      roleService.getRoleByNameAndScope.mockResolvedValue(role);
      const result = await service.getAdminRole('superadmin');
      expect(result).toEqual(role);
    });

    it('should throw if admin role not found', async () => {
      roleService.getRoleByNameAndScope.mockResolvedValue(null);
      await expect(service.getAdminRole('admin')).rejects.toThrow(NotFoundException);
    });
  });
});
