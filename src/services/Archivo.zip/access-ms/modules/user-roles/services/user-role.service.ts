import { ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { UserRole } from '../models/user-role.entity';
import { EntityManager, Repository } from 'typeorm';
import { Role } from '../../role/models/role.entity';
import { User } from '@/services/identity-ms/modules/user/models/user.entity';
import { RoleType } from '@/services/access-ms/modules/role/types/role.type';
import { Organization } from '@/services/organization-ms/modules/orgnanization/models/organization.entity';
import { RoleService } from '../../role/services/role.service';
import { ScopeType } from '@/services/organization-ms/modules/orgnanization/types/scope.type';

@Injectable()
export class UserRoleService {
  constructor(
    @InjectRepository(UserRole)
    private readonly userRoleRepository: Repository<UserRole>,
    private readonly roleService: RoleService,
  ) {}
  async createUserRole(
    user: User,
    role: Role | RoleType,
    scope: ScopeType,
    organization: Organization,
    manager?: EntityManager,
  ): Promise<UserRole> {
    const repo = manager?.getRepository(UserRole) ?? this.userRoleRepository;
    if (role instanceof Role) {
      const userRole = repo.create({
        user_id: user.id,
        role_id: role.id,
        scope,
        organization_id: organization.id,
      });
      return repo.save(userRole);
    }

    const roleEntity = await this.roleService.getRoleByNameAndScope(role, scope);

    if (!roleEntity) {
      throw new ConflictException(`Role ${role} not found for scope ${organization.id}`);
    }

    const userRole = repo.create({
      user_id: user.id,
      role_id: roleEntity.id,
      scope,
      organization_id: organization.id,
    });
    return repo.save(userRole);
  }
  async findByUserId(userId: string): Promise<UserRole[]> {
    return this.userRoleRepository.find({ where: { user_id: userId } });
  }
  async findByRoleId(roleId: string): Promise<UserRole[]> {
    return this.userRoleRepository.find({ where: { role_id: roleId } });
  }
  async findByUserIdAndRoleId(userId: string, roleId: string): Promise<UserRole | null> {
    return this.userRoleRepository.findOne({
      where: { user_id: userId, role_id: roleId },
    });
  }
  async assignRoleToUser(userId: string, roleId: string): Promise<UserRole> {
    const userRole = this.userRoleRepository.create({
      user_id: userId,
      role_id: roleId,
    });
    return this.userRoleRepository.save(userRole);
  }
  async removeRoleFromUser(userId: string, roleId: string): Promise<void> {
    const userRole = await this.findByUserIdAndRoleId(userId, roleId);
    if (userRole) {
      await this.userRoleRepository.remove(userRole);
    }
  }
  async getAllUserRoles(): Promise<UserRole[]> {
    return this.userRoleRepository.find();
  }
  async getUserRolesByUserId(userId: string): Promise<UserRole[]> {
    return this.userRoleRepository.find({ where: { user_id: userId } });
  }

  async assignRole(user: User, roleName: RoleType, scope: ScopeType, organization?: Organization) {
    const role = await this.roleService.getRoleByNameAndScope(roleName, scope);

    const exists = await this.findByUserIdAndRoleId(user.id, role.id);
    if (exists) return exists;

    return this.createUserRole(user, role.name, scope, organization);
  }

  async getAdminRole(role: 'superadmin' | 'admin' = 'superadmin') {
    const roleEntity = await this.roleService.getRoleByNameAndScope(role, 'global');
    if (!roleEntity) {
      throw new NotFoundException(`Role ${role} not found`);
    }
    return roleEntity;
  }
}
