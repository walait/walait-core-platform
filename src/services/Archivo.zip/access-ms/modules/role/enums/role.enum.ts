export enum RoleEnum {
  Superadmin = 'superadmin',
  Admin = 'admin',
  Owner = 'owner',
  Member = 'member',
}
