import { Entity, PrimaryGeneratedColumn, Column, OneToMany, Index } from 'typeorm';
import { UserRole } from '../../user-roles/models/user-role.entity';
import { RolePermission } from '../../role-permission/models/role-permission.entity';
import { RoleType } from '@/services/access-ms/modules/role/types/role.type';
import { ScopeType } from '@/services/organization-ms/modules/orgnanization/types/scope.type';
import { Permission } from '../../permission/models/permission.entity';

@Index('name_scope_index', ['name', 'scope'])
@Entity('roles')
export class Role {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  name: RoleType;

  @Column({ default: 'organization' })
  scope: ScopeType;

  @Column({ nullable: true })
  organization_id: string;

  @OneToMany(() => RolePermission, (rp) => rp.role)
  rolePermissions: RolePermission[];

  @OneToMany(() => RolePermission, (rp) => rp.permission)
  permission: Permission[];
}
