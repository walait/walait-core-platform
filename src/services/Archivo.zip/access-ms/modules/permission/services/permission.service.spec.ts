// apps/access/services/permission.service.spec.ts
import { Test, TestingModule } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { PermissionService } from './permission.service';
import { UserRole } from '@/services/access-ms/modules/user-roles/models/user-role.entity';

// ───────────────────────────────────────────
// Mock factory del repo
// ───────────────────────────────────────────
const repoMock = () =>
  ({
    find: jest.fn(),
  }) as unknown as jest.Mocked<Repository<UserRole>>;

// ───────────────────────────────────────────
// Datos dummy
// ───────────────────────────────────────────
const makeUserRole = (userId: string, roleName: string, perms: string[]): UserRole =>
  ({
    id: `${roleName}-ur`,
    user: { id: userId } as any,
    role: {
      name: roleName,
      rolePermissions: perms.map((name) => ({ permission: { name } }) as any),
    } as any,
  }) as UserRole;

describe('PermissionService', () => {
  let service: PermissionService;
  let urRepo: jest.Mocked<Repository<UserRole>>;

  const USER_ID = 'u-1';

  beforeEach(async () => {
    urRepo = repoMock();

    const module: TestingModule = await Test.createTestingModule({
      providers: [PermissionService, { provide: getRepositoryToken(UserRole), useValue: urRepo }],
    }).compile();

    service = module.get(PermissionService);
    jest.clearAllMocks();
  });

  // ───────────────── listPermissions
  describe('listPermissions', () => {
    it('devuelve permisos únicos de todas las roles', async () => {
      urRepo.find.mockResolvedValue([
        makeUserRole(USER_ID, 'admin', ['read', 'write']),
        makeUserRole(USER_ID, 'member', ['read']), // duplicado 'read'
      ]);

      const perms = await service.listPermissions(USER_ID);

      expect(perms.sort()).toEqual(['read', 'write']);
      expect(urRepo.find).toHaveBeenCalledWith({
        where: { user: { id: USER_ID } },
        relations: ['role', 'role.permissions'],
      });
    });
  });

  // ───────────────── hasPermission
  describe('hasPermission', () => {
    it('true si el permiso está presente', async () => {
      urRepo.find.mockResolvedValue([makeUserRole(USER_ID, 'admin', ['export'])]);

      const ok = await service.hasPermission(USER_ID, 'export');
      expect(ok).toBe(true);
    });

    it('false si el permiso NO está presente', async () => {
      urRepo.find.mockResolvedValue([makeUserRole(USER_ID, 'member', ['read'])]);

      const ok = await service.hasPermission(USER_ID, 'delete');
      expect(ok).toBe(false);
    });
  });

  // ───────────────── hasRoleOrHigher
  describe('hasRoleOrHigher', () => {
    it('true si el usuario tiene rol igual o superior', async () => {
      // user es 'owner', required 'admin' -> debería pasar
      urRepo.find.mockResolvedValue([makeUserRole(USER_ID, 'owner', [])]);

      const ok = await service.hasRoleOrHigher(USER_ID, 'admin');
      expect(ok).toBe(true);
    });

    it('false si el usuario no llega al nivel requerido', async () => {
      urRepo.find.mockResolvedValue([makeUserRole(USER_ID, 'member', [])]);

      const ok = await service.hasRoleOrHigher(USER_ID, 'owner');
      expect(ok).toBe(false);
    });
  });
});
