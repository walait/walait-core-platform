import { Test, TestingModule } from '@nestjs/testing';
import { EmailVerificationController } from './verification.controller';
import { EmailVerificationService } from '../services/verification.service';
import { UserService } from '../../identity-ms/modules/user/services/user.service';
import { TokenService } from '../../identity-ms/modules/token/services/token.service';
import { BadRequestException } from '@nestjs/common';
import { EmailService } from '@/services/email-ms/services/email.service';

describe('EmailVerificationController', () => {
  let controller: EmailVerificationController;

  // — Mocks de dependencias — //
  const emailVerificationService = {
    getEmailVerificationToken: jest.fn(),
    createVerificationTokenEmail: jest.fn(),
  };

  const userService = {
    findById: jest.fn(),
    updateUser: jest.fn(),
    toResponse: jest.fn(),
  };

  const tokenService = {
    generateToken: jest.fn(),
  };

  const emailService = {
    getAllTemplates: jest.fn(),
    getTemplateBySlug: jest.fn(),
    sendEmailWithTemplate: jest.fn(),
    syncTemplates: jest.fn(),
    getTemplateById: jest.fn(),
  };
  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [EmailVerificationController],
      providers: [
        { provide: EmailVerificationService, useValue: emailVerificationService },
        { provide: UserService, useValue: userService },
        { provide: TokenService, useValue: tokenService },
        { provide: EmailService, useValue: emailService },
      ],
    }).compile();

    controller = module.get(EmailVerificationController);
    jest.clearAllMocks();
  });

  /* ------------------------------------------------------------------
     verify-email
  ------------------------------------------------------------------ */
  describe('verifyEmail', () => {
    const tokenPayload = {
      user: { id: 'user-1' },
      expires_at: new Date(Date.now() + 3_600_000),
    };

    it('debería verificar el email correctamente', async () => {
      emailVerificationService.getEmailVerificationToken.mockResolvedValue({ token: tokenPayload });
      const user = { id: 'user-1', is_email_verified: false };
      userService.findById.mockResolvedValue(user);
      userService.updateUser.mockResolvedValue({ ...user, is_email_verified: true });
      userService.toResponse.mockReturnValue({ id: user.id });

      const result = await controller.verifyEmail('abc123');

      expect(userService.updateUser).toHaveBeenCalledWith({ ...user, is_email_verified: true });
      expect(result).toEqual({
        message: 'Email verified successfully',
        user: { id: 'user-1' },
      });
    });

    it('debería lanzar BadRequest si el token no existe', async () => {
      emailVerificationService.getEmailVerificationToken.mockResolvedValue({ token: null });
      await expect(controller.verifyEmail('invalid')).rejects.toThrow(BadRequestException);
    });

    it('debería lanzar BadRequest si el usuario no existe', async () => {
      emailVerificationService.getEmailVerificationToken.mockResolvedValue({ token: tokenPayload });
      userService.findById.mockResolvedValue(null);
      await expect(controller.verifyEmail('abc123')).rejects.toThrow(BadRequestException);
    });

    it('debería lanzar BadRequest si el email ya está verificado', async () => {
      emailVerificationService.getEmailVerificationToken.mockResolvedValue({ token: tokenPayload });
      userService.findById.mockResolvedValue({ id: 'user-1', is_email_verified: true });
      await expect(controller.verifyEmail('abc123')).rejects.toThrow(BadRequestException);
    });
  });

  /* ------------------------------------------------------------------
     resend-verification
  ------------------------------------------------------------------ */
  describe('resendVerification', () => {
    const reqFactory = (user: any = null) => ({ user });

    it('debería reenviar verificación con éxito', async () => {
      const user = { id: 'user-1', is_email_verified: false };
      userService.findById.mockResolvedValue(user);

      tokenService.generateToken.mockResolvedValue('jwt-token');
      emailVerificationService.createVerificationTokenEmail.mockResolvedValue({
        token: 'jwt-token',
        expires_at: expect.any(Date),
      });

      const result = await controller.resendVerification(reqFactory({ sub: user.id }));

      expect(tokenService.generateToken).toHaveBeenCalled();
      expect(emailVerificationService.createVerificationTokenEmail).toHaveBeenCalledWith(
        user,
        'jwt-token',
        expect.any(Date),
      );
      expect(result).toEqual({
        token: 'jwt-token',
        expires_at: expect.any(Date),
      });
    });

    it('debería lanzar BadRequest si req.user es nulo', async () => {
      await expect(controller.resendVerification(reqFactory(null))).rejects.toThrow(
        BadRequestException,
      );
    });

    it('debería lanzar BadRequest si el usuario no existe', async () => {
      userService.findById.mockResolvedValue(null);
      await expect(controller.resendVerification(reqFactory({ sub: 'ghost' }))).rejects.toThrow(
        BadRequestException,
      );
    });

    it('debería lanzar BadRequest si el email ya está verificado', async () => {
      userService.findById.mockResolvedValue({ id: 'user-1', is_email_verified: true });
      await expect(controller.resendVerification(reqFactory({ sub: 'user-1' }))).rejects.toThrow(
        BadRequestException,
      );
    });
  });
});
