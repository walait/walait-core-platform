import {
  BadRequestException,
  Controller,
  Get,
  Post,
  Query,
  Redirect,
  Req,
  Res,
  UseGuards,
} from '@nestjs/common';

import { JwtAuthGuard } from '@/services/identity-ms/guards/jwt.guard';
import { OrganizationService } from '@/services/organization-ms/modules/orgnanization/services/organization.service';
import { VerificationService } from '../services/verification.service';
import { TokenService } from '@/services/identity-ms/modules/token/services/token.service';
import { UserService } from '@/services/identity-ms/modules/user/services/user.service';
@Controller('email-verification-ms')
export class VerificationController {
  constructor(
    private readonly vericationService: VerificationService,
    private readonly userService: UserService,
    private readonly tokenService: TokenService,
    private readonly organizationService: OrganizationService,
  ) {}

  @Get('verify-email')
  @Redirect()
  async verifyEmail(
    @Query('token') emailToken: string,
    @Query('organization_id') organizationId: string,
  ) {
    const { token } = await this.vericationService.getEmailVerificationToken(emailToken);

    if (!token) {
      throw new BadRequestException('Invalid or expired token');
    }

    const user = await this.userService.findById(token.user_id);

    if (!user) {
      throw new BadRequestException('User not found');
    }

    if (user.is_email_verified) {
      throw new BadRequestException('Email already verified');
    }

    user.is_email_verified = true;

    await this.userService.updateUser(user);

    const organization = await this.organizationService.getOrganizationById(organizationId);
    const domain = organization.domain.startsWith('http')
      ? (organization.domain ?? process.env.BACKED_URL)
      : `https://${organization.domain}`;

    return { url: domain, status: 3012 };
  }

  @Post('resend-verification')
  @UseGuards(JwtAuthGuard)
  async resendVerification(@Req() req) {
    const user = req.user;

    if (!user) throw new BadRequestException('User not found');

    const existingUser = await this.userService.findById(user.sub);

    if (!existingUser) {
      throw new BadRequestException('User not found');
    }

    if (existingUser.is_email_verified) {
      throw new BadRequestException('Email already verified');
    }

    const expirationAt = new Date(Date.now() + 1 * 60 * 60 * 1000);

    const token = await this.tokenService.generateToken(
      {
        userId: existingUser.id,
        type: 'email_verification',
        expiration_at: Math.floor(Date.now() / 1000) + 60 * 60,
      },
      process.env.EMAIL_VERIFICATION_SECRET,
      '1h',
    );

    return await this.vericationService.createToken(existingUser.id, token, expirationAt);
  }
}
