import { Test, TestingModule } from '@nestjs/testing';
import { BadRequestException } from '@nestjs/common';
import { EmailService } from '../../email/services/email.service';
import { VerificationService } from '../services/verification.service';
import { TokenService } from '@/services/identity-ms/modules/token/services/token.service';
import { UserService } from '@/services/identity-ms/modules/user/services/user.service';
import { VerificationController } from './verification.controller';

describe('VerificationController', () => {
  let controller: VerificationController;

  // — Mocks de dependencias — //
  const verificationService = {
    createToken: jest.fn(),
    findToken: jest.fn(),
    findTokensByUserId: jest.fn(),
    deleteExpiredTokens: jest.fn(),
    deleteAllTokens: jest.fn(),
    getEmailVerificationToken: jest.fn(),
  };

  const userService = {
    findById: jest.fn(),
    updateUser: jest.fn(),
    toResponse: jest.fn(),
  };

  const tokenService = {
    generateToken: jest.fn(),
  };

  const emailService = {
    getAllTemplates: jest.fn(),
    getTemplateBySlug: jest.fn(),
    sendEmailWithTemplate: jest.fn(),
    syncTemplates: jest.fn(),
    getTemplateById: jest.fn(),
  };
  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [VerificationController],
      providers: [
        { provide: VerificationService, useValue: verificationService },
        { provide: UserService, useValue: userService },
        { provide: TokenService, useValue: tokenService },
        { provide: EmailService, useValue: emailService },
      ],
    }).compile();

    controller = module.get(VerificationController);
    jest.clearAllMocks();
  });

  /* ------------------------------------------------------------------
     verify-email
  ------------------------------------------------------------------ */
  describe('verifyEmail', () => {
    const tokenPayload = {
      user: { id: 'user-1' },
      expires_at: new Date(Date.now() + 3_600_000),
    };

    it('debería verificar el email correctamente', async () => {
      verificationService.getEmailVerificationToken.mockResolvedValue({ token: tokenPayload });
      const user = { id: 'user-1', is_email_verified: false };
      userService.findById.mockResolvedValue(user);
      userService.updateUser.mockResolvedValue({ ...user, is_email_verified: true });
      userService.toResponse.mockReturnValue({ id: user.id });

      const result = await controller.verifyEmail('abc123', 'org-123');

      expect(userService.updateUser).toHaveBeenCalledWith({ ...user, is_email_verified: true });
      expect(result).toEqual({
        message: 'Email verified successfully',
        user: { id: 'user-1' },
      });
    });

    it('debería lanzar BadRequest si el token no existe', async () => {
      verificationService.getEmailVerificationToken.mockResolvedValue({ token: null });
      await expect(controller.verifyEmail('invalid', null)).rejects.toThrow(BadRequestException);
    });

    it('debería lanzar BadRequest si el usuario no existe', async () => {
      verificationService.getEmailVerificationToken.mockResolvedValue({ token: tokenPayload });
      userService.findById.mockResolvedValue(null);
      await expect(controller.verifyEmail('abc-123', 'abc123')).rejects.toThrow(
        BadRequestException,
      );
    });

    it('debería lanzar BadRequest si el email ya está verificado', async () => {
      verificationService.getEmailVerificationToken.mockResolvedValue({ token: tokenPayload });
      userService.findById.mockResolvedValue({ id: 'user-1', is_email_verified: true });
      await expect(controller.verifyEmail('abc123', 'abc-123')).rejects.toThrow(
        BadRequestException,
      );
    });
  });

  /* ------------------------------------------------------------------
     resend-verification
  ------------------------------------------------------------------ */
  describe('resendVerification', () => {
    const reqFactory = (user: any = null) => ({ user });

    it('debería reenviar verificación con éxito', async () => {
      const user = { id: 'user-1', is_email_verified: false };
      userService.findById.mockResolvedValue(user);

      tokenService.generateToken.mockResolvedValue('jwt-token');
      verificationService.createToken.mockResolvedValue({
        token: 'jwt-token',
        expires_at: expect.any(Date),
      });

      const result = await controller.resendVerification(reqFactory({ sub: user.id }));

      expect(tokenService.generateToken).toHaveBeenCalled();
      expect(verificationService.createToken).toHaveBeenCalledWith(
        user,
        'jwt-token',
        expect.any(Date),
      );
      expect(result).toEqual({
        token: 'jwt-token',
        expires_at: expect.any(Date),
      });
    });

    it('debería lanzar BadRequest si req.user es nulo', async () => {
      await expect(controller.resendVerification(reqFactory(null))).rejects.toThrow(
        BadRequestException,
      );
    });

    it('debería lanzar BadRequest si el usuario no existe', async () => {
      userService.findById.mockResolvedValue(null);
      await expect(controller.resendVerification(reqFactory({ sub: 'ghost' }))).rejects.toThrow(
        BadRequestException,
      );
    });

    it('debería lanzar BadRequest si el email ya está verificado', async () => {
      userService.findById.mockResolvedValue({ id: 'user-1', is_email_verified: true });
      await expect(controller.resendVerification(reqFactory({ sub: 'user-1' }))).rejects.toThrow(
        BadRequestException,
      );
    });
  });
});
