// email-ms/listeners/email-verification.listener.ts
import { OnEvent } from '@nestjs/event-emitter';
import { Injectable } from '@nestjs/common';
import { EmailService } from '../../email/services/email.service';
import { VerificationService } from '../services/verification.service';
import { ConfigService } from '@nestjs/config';

type EmailVerificationEvent = {
  user_id: string;
  email: string;
  first_name: string;
  last_name: string;
  organization_id: string;
  organization_slug: string;
  domain?: string;
  template_slug: string;
  token: string;
  token_expiration_at: Date;
};

@Injectable()
export class EmailVerificationListener {
  constructor(
    private readonly emailService: EmailService,
    private readonly verificationService: VerificationService,
    private readonly config: ConfigService,
  ) {}

  @OnEvent('email.verification_requested', { async: true })
  async handleEmailVerificationRequested(event: EmailVerificationEvent) {
    const {
      user_id,
      email,
      first_name,
      last_name,
      organization_id,
      organization_slug,
      domain,
      template_slug,
      token_expiration_at,
      token,
    } = event;

    const verification = await this.verificationService.createToken(
      user_id,
      token,
      token_expiration_at,
    );
    if (!verification) throw new Error('Failed to generate token');

    const template = await this.emailService.getTemplateBySlug(template_slug);
    if (!template) throw new Error('Template not found');

    const baseUrl = this.config.get('EMAIL_VERIFICATION_URL');
    const verificationLink = `${baseUrl}?token=${verification.token}&organization_id=${organization_id}`;

    await this.emailService.sendEmailWithTemplate(template, email, 'Confirma tu cuenta', {
      firstName: first_name,
      lastName: last_name,
      verification_link: verificationLink,
      app_name: organization_slug ?? 'WalaTech',
    });
  }
}
