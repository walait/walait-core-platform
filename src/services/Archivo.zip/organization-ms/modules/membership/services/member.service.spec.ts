import { Test, TestingModule } from '@nestjs/testing';
import { MemberService } from './member.service';
import { getRepositoryToken } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Membership } from '../models/membership.entity';
import { NotFoundException } from '@nestjs/common';
import { User } from '../../../../identity-ms/modules/user/models/user.entity';

// Utilidad para crear mocks de repositorio TypeORM
const createMockRepo = <T = any>(): jest.Mocked<Partial<Repository<T>>> => ({
  find: jest.fn(),
  findOne: jest.fn(),
  create: jest.fn(),
  save: jest.fn(),
  update: jest.fn(),
  delete: jest.fn(),
});

describe('MemberService', () => {
  let service: MemberService;
  let repo: jest.Mocked<Partial<Repository<Membership>>>;

  const mockMembership: Membership = {
    id: 'mem-1',
    user_id: 'user-1',
    organization: { id: 'org-1' } as any,
  } as Membership;

  beforeEach(async () => {
    repo = createMockRepo();

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        MemberService,
        {
          provide: getRepositoryToken(Membership),
          useValue: repo,
        },
      ],
    }).compile();

    service = module.get(MemberService);
    jest.clearAllMocks();
  });

  describe('findById', () => {
    it('returns membership by id', async () => {
      (repo.findOne as jest.Mock).mockResolvedValue(mockMembership);
      const result = await service.findById('mem-1');
      expect(repo.findOne).toHaveBeenCalledWith({ where: { id: 'mem-1' } });
      expect(result).toEqual(mockMembership);
    });
  });

  describe('findByUserId', () => {
    it('returns memberships for user', async () => {
      (repo.find as jest.Mock).mockResolvedValue([mockMembership]);
      const result = await service.findByUserId('user-1');
      expect(repo.find).toHaveBeenCalledWith({ where: { user: { id: 'user-1' } } });
      expect(result).toEqual([mockMembership]);
    });
  });

  describe('createMembership', () => {
    it('creates membership', async () => {
      (repo.create as jest.Mock).mockReturnValue(mockMembership);
      (repo.save as jest.Mock).mockResolvedValue(mockMembership);
      const result = await service.createMembership(mockMembership);
      expect(repo.create).toHaveBeenCalledWith(mockMembership);
      expect(repo.save).toHaveBeenCalledWith(mockMembership);
      expect(result).toEqual(mockMembership);
    });
  });

  describe('updateMembership', () => {
    it('updates membership and returns updated entity', async () => {
      (repo.update as jest.Mock).mockResolvedValue(undefined);
      (repo.findOne as jest.Mock).mockResolvedValue(mockMembership);
      const result = await service.updateMembership('mem-1', { user_id: 'asdf-123' });
      expect(repo.update).toHaveBeenCalledWith('mem-1', { user_id: 'asdf-123' });
      expect(result).toEqual(mockMembership);
    });
  });

  describe('deleteMembership', () => {
    it('deletes membership', async () => {
      (repo.delete as jest.Mock).mockResolvedValue(undefined);
      await service.deleteMembership('mem-1');
      expect(repo.delete).toHaveBeenCalledWith('mem-1');
    });
  });

  describe('getMembershipAndOrg', () => {
    it('returns membership with org relation', async () => {
      (repo.findOne as jest.Mock).mockResolvedValue(mockMembership);
      const result = await service.getMembershipAndOrg('user-1');
      expect(repo.findOne).toHaveBeenCalledWith({
        where: { user: { id: 'user-1' } },
        relations: ['organization'],
      });
      expect(result).toEqual(mockMembership);
    });

    it('throws NotFoundException if not found', async () => {
      (repo.findOne as jest.Mock).mockResolvedValue(null);
      await expect(service.getMembershipAndOrg('user-1')).rejects.toThrow(NotFoundException);
    });
  });

  describe('getMembershipsByOrganizationId', () => {
    it('returns memberships by org id', async () => {
      (repo.find as jest.Mock).mockResolvedValue([mockMembership]);
      const result = await service.getMembershipsByOrganizationId('org-1');
      expect(repo.find).toHaveBeenCalledWith({ where: { organization: { id: 'org-1' } } });
      expect(result).toEqual([mockMembership]);
    });
  });
});
