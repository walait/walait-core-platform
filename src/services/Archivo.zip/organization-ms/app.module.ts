import { Module } from '@nestjs/common';
import { MemberService } from './modules/membership/services/member.service';
import { OrganizationService } from './modules/orgnanization/services/organization.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Organization } from './modules/orgnanization/models/organization.entity';
import { Membership } from './modules/membership/models/membership.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Organization, Membership])],
  providers: [MemberService, OrganizationService],
  exports: [MemberService, OrganizationService],
})
export class OrganizationModule {}
