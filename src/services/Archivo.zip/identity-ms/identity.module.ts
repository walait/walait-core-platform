import { Module } from '@nestjs/common';
import { AuthModule } from './modules/auth/auth.module';
import { SessionModule } from './modules/session/session.module';
import { PasswordModule } from './modules/password/password.module';
import { UserModule } from './modules/user/user.module';
import { JwtAuthGuard } from './guards/jwt.guard';
import { APP_GUARD } from '@nestjs/core';
import { JwtModule } from '@nestjs/jwt';
import { TokenModule } from './modules/token/token.module';
import { ClientsModule, Transport } from '@nestjs/microservices';
import { EmailModule } from '../email-ms/email.module';

@Module({
  imports: [
    ClientsModule.register([
      {
        name: 'EVENT_BUS',
        transport: Transport.RMQ,
        options: {
          urls: [process.env.RABBITMQ_URL],
          queue: 'identity_queue',
          queueOptions: { durable: true },
        },
      },
    ]),
    AuthModule,
    EmailModule,
    SessionModule,
    PasswordModule,
    UserModule,
    JwtModule.register({
      secret: process.env.JWT_SECRET,
      signOptions: { expiresIn: '15m' },
    }),
    TokenModule,
  ],
  providers: [{ provide: APP_GUARD, useClass: JwtAuthGuard }],
  exports: [UserModule, SessionModule],
})
export class IdentityModule {}
