import { Module } from '@nestjs/common';
import { AuthController } from './controller/auth.controller';
import { AuthService } from './services/auth.service';
import { UserModule } from '../user/user.module';
import { PasswordModule } from '../password/password.module';
import { SessionModule } from '../session/session.module';
import { AccessModule } from '@/services/access-ms/access.module';
import { OrganizationModule } from '@/services/organization-ms/app.module';
import { EmailModule } from '@/services/email-ms/email.module';

@Module({
  imports: [
    UserModule,
    SessionModule,
    AccessModule,
    OrganizationModule,
    PasswordModule,
    EmailModule,
  ],
  controllers: [AuthController],
  exports: [],
  providers: [AuthService],
})
export class AuthModule {}
