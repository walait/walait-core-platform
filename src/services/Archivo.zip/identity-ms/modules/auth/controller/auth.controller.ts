import { Body, Controller, Post, Req, Res, UseGuards, UsePipes } from '@nestjs/common';
import { AuthService } from '@/services/identity-ms/modules/auth/services/auth.service';
import { ZodValidationPipe } from 'nestjs-zod';
import { ClientInfo } from '@/shared/decorators/clientInfo.decorator';

import { ConfigService } from '@nestjs/config';
import { SignInInput, SignUpSchema, SignUpInput } from '../schemas/auth.schema';
import { JwtAuthGuard } from '@/services/identity-ms/guards/jwt.guard';
import { Response } from 'express';
import { SignInSchema } from '../schemas/auth.schema';
@Controller('auth')
export class AuthController {
  constructor(
    private readonly authService: AuthService,
    private readonly configService: ConfigService,
  ) {}

  @UsePipes(new ZodValidationPipe(SignInSchema))
  @Post('sign-in')
  async signIn(
    @Body() dto: SignInInput,
    @ClientInfo() clientInfo: { ipAddress: string; userAgent: string },
    @Res({ passthrough: true }) response: Response,
  ) {
    const result = await this.authService.signIn(dto, clientInfo);

    response.cookie('refresh_token', result.session.refresh_token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'PRODUCTION',
      sameSite: 'lax',
      path: '/',
      maxAge: 7 * 24 * 60 * 60 * 1000,
    });

    return response.status(200).send(result);
  }

  @UsePipes(new ZodValidationPipe(SignUpSchema))
  @Post('sign-up')
  signUp(
    @Body() dto: SignUpInput,
    @ClientInfo() clientInfo: { ipAddress: string; userAgent: string },
  ) {
    return this.authService.signUp(dto, clientInfo);
  }

  @Post('refresh-token')
  refresh(@Body() req) {
    const refreshToken = req.cookies?.['refresh_token'];
    return this.authService.refreshToken(refreshToken);
  }

  @Post('logout')
  @UseGuards(JwtAuthGuard)
  logout(@Req() req, @Res({ passthrough: true }) res: Response) {
    res.clearCookie('refresh_token', { path: '/' });
    return this.authService.logout(req.user.sid);
  }
}
