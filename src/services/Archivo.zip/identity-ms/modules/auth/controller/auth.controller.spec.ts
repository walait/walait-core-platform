// src/apps/auth/auth.controller.spec.ts
import { Test, TestingModule } from '@nestjs/testing';
import { AuthController } from './auth.controller';
import { AuthService } from '@/services/identity-ms/modules/auth/services/auth.service';
import { ConfigService } from '@nestjs/config';
import { GUARDS_METADATA } from '@nestjs/common/constants';
import { JwtAuthGuard } from '@/services/identity-ms/guards/jwt.guard';
import { TokenService } from '../../token/services/token.service';

// ──────────────────────────────────────────────────
// Mocks
// ──────────────────────────────────────────────────
const authServiceMock = {
  login: jest.fn(),
  signUp: jest.fn(),
  refreshToken: jest.fn(),
  logout: jest.fn(),
};

const configServiceMock = {
  get: jest.fn(),
};

const tokenServiceMock = {
  generateAccessToken: jest.fn(),
  generateRefreshToken: jest.fn(),
  verifyAccessToken: jest.fn(),
  verifyRefreshToken: jest.fn(),
  decodePayload: jest.fn(),
  generateSessionSecret: jest.fn(),
};

// ──────────────────────────────────────────────────
// Suite
// ──────────────────────────────────────────────────
describe('AuthController', () => {
  let controller: AuthController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [AuthController],
      providers: [
        { provide: AuthService, useValue: authServiceMock },
        { provide: ConfigService, useValue: configServiceMock },
        {
          provide: TokenService,
          useValue: tokenServiceMock,
        },
      ],
    }).compile();

    controller = module.get(AuthController);
    jest.clearAllMocks();
  });

  // ------------------------------------------------ signIn
  it('signIn llama AuthService.login con dto y clientInfo', async () => {
    const dto = { email: 'a@test.com', password: '123' } as any;
    const info = { ipAddress: '1.1.1.1', userAgent: 'jest' };
    authServiceMock.login.mockResolvedValue('ok');

    const res = await controller.signIn(dto, info);

    expect(authServiceMock.login).toHaveBeenCalledWith(dto, info);
    expect(res).toBe('ok');
  });

  // ------------------------------------------------ signUp
  it('signUp obtiene flags de config y llama AuthService.signUp', async () => {
    const dto = {
      email: 'b@test.com',
      password: 'p',
      organization_id: 'org',
      role: 'member',
    } as any;
    const info = { ipAddress: '2.2.2.2', userAgent: 'jest' };
    configServiceMock.get.mockImplementation((key: string) =>
      key === 'ALLOW_GLOBAL_SIGN_UP' ? true : 'global-secret',
    );
    authServiceMock.signUp.mockResolvedValue('signed');

    const res = await controller.signUp(dto, info);

    expect(configServiceMock.get).toHaveBeenNthCalledWith(1, 'ALLOW_GLOBAL_SIGN_UP');
    expect(configServiceMock.get).toHaveBeenNthCalledWith(2, 'GLOBAL_SECRET_KEY');
    expect(authServiceMock.signUp).toHaveBeenCalledWith(dto, info, true, 'global-secret');
    expect(res).toBe('signed');
  });

  // ------------------------------------------------ refresh
  it('refresh delega en AuthService.refreshToken', async () => {
    const dto = { refresh_token: 'rt' } as any;
    authServiceMock.refreshToken.mockResolvedValue('refreshed');

    const res = await controller.refresh(dto);

    expect(authServiceMock.refreshToken).toHaveBeenCalledWith(dto);
    expect(res).toBe('refreshed');
  });

  // ------------------------------------------------ logout
  it('logout delega en AuthService.logout usando req.user.sid', async () => {
    const sid = 'sess-1';
    authServiceMock.logout.mockResolvedValue(undefined);

    const result = await controller.logout({ user: { sid } } as any);

    expect(authServiceMock.logout).toHaveBeenCalledWith(sid);
    expect(result).toBeUndefined();
  });

  // ------------------------------------------------ metadata: JwtAuthGuard en logout
  it('logout tiene el guard JwtAuthGuard aplicado', () => {
    const guards = Reflect.getMetadata(GUARDS_METADATA, controller.logout);
    expect(guards).toContain(JwtAuthGuard);
  });
});
