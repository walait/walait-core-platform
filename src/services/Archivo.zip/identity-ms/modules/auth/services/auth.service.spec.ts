import { Test, TestingModule } from '@nestjs/testing';
import { AuthService } from './auth.service';
import { SessionService } from '../../session/services/session.service';
import { TokenService } from '../../token/services/token.service';
import { UserService } from '../../user/services/user.service';
import { MemberService } from '../../../../organization-ms/modules/membership/services/member.service';
import { EmailVerificationService } from '../../../../email-ms/services/verification.service';
import { OrganizationService } from '../../../../../apps/identity/services/organization.service';
import { AccessService } from '@/services/access-ms/services/access.service';
import { PasswordService } from '../../password/services/password.service';
import {
  ConflictException,
  ForbiddenException,
  NotFoundException,
  UnauthorizedException,
} from '@nestjs/common';
import { EmailService } from '@/services/email-ms/services/email.service';
import { DataSource } from 'typeorm';

// -------------------- mocks -------------------- //
const userService = {
  findByEmail: jest.fn(),
  createUser: jest.fn(),
  existsByEmail: jest.fn(),
  toResponse: jest.fn(),
};

const sessionService = {
  getActiveByUser: jest.fn(),
  create: jest.fn(),
  updateWithNewTokens: jest.fn(),
  getActiveSessionById: jest.fn(),
  verifyTokenHash: jest.fn(),
  toResponse: jest.fn(),
  revokeSession: jest.fn(),
};

const tokenService = {
  decodePayload: jest.fn(),
  verifyRefreshToken: jest.fn(),
  generateToken: jest.fn(),
  generateSessionSecret: jest.fn(),
  generateAccessToken: jest.fn(),
  generateRefreshToken: jest.fn(),
};

const membershipService = {
  getMembershipAndOrg: jest.fn(),
  createMembership: jest.fn(),
};

const emailVerificationService = {
  createVerificationTokenEmail: jest.fn(),
};

const organizationService = {
  getOrganizationById: jest.fn(),
};

const accessService = {
  assignInitialRole: jest.fn(),
};

const passwordService = {
  checkPassword: jest.fn(),
  hashPassword: jest.fn(),
};

const emailService = {
  getAllTemplates: jest.fn(),
  getTemplateBySlug: jest.fn(),
  sendEmailWithTemplate: jest.fn(),
  syncTemplates: jest.fn(),
  getTemplateById: jest.fn(),
};

// DataSource mock con transacción "passthrough"
const dataSource = {
  transaction: jest.fn(async (cb) => cb({ getRepository: jest.fn() })),
};

// ------------------ inicio tests ------------------ //
describe('AuthService', () => {
  let service: AuthService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AuthService,
        { provide: DataSource, useValue: dataSource },
        { provide: UserService, useValue: userService },
        { provide: SessionService, useValue: sessionService },
        { provide: TokenService, useValue: tokenService },
        { provide: MemberService, useValue: membershipService },
        { provide: EmailVerificationService, useValue: emailVerificationService },
        { provide: OrganizationService, useValue: organizationService },
        { provide: AccessService, useValue: accessService },
        { provide: PasswordService, useValue: passwordService },
        { provide: EmailService, useValue: emailService },
      ],
    }).compile();

    service = module.get<AuthService>(AuthService);
    jest.clearAllMocks();
  });

  // ---------- login ---------- //
  describe('login', () => {
    it('should throw if user not found', async () => {
      userService.findByEmail.mockResolvedValue(null);
      await expect(
        service.signIn(
          { email: 'test@test.com', password: '1234' },
          { ipAddress: '', userAgent: '' },
        ),
      ).rejects.toThrow(NotFoundException);
    });

    it('should throw if password is invalid', async () => {
      userService.findByEmail.mockResolvedValue({ id: 'user1', is_email_verified: true });
      passwordService.checkPassword.mockResolvedValue(false);
      await expect(
        service.signIn(
          { email: 'test@test.com', password: 'wrong' },
          { ipAddress: '', userAgent: '' },
        ),
      ).rejects.toThrow(UnauthorizedException);
    });

    it('should return user, session and token data', async () => {
      const user = { id: 'user1', email: 'test@test.com', is_email_verified: true };
      const session = { id: 'sess1' };
      const tokens = {
        access_token: 'access',
        refresh_token: 'refresh',
        sessionSecret: 'secret',
        expires_at: new Date(),
      };

      userService.findByEmail.mockResolvedValue(user);
      passwordService.checkPassword.mockResolvedValue(true);
      sessionService.getActiveByUser.mockResolvedValue({
        ip_address: '1.2.3.4',
        user_agent: 'Agent',
      });
      sessionService.create.mockResolvedValue(session);
      membershipService.getMembershipAndOrg.mockResolvedValue({
        organization: { id: 'org' },
        role: 'admin',
      });
      tokenService.generateAccessToken.mockResolvedValue(tokens.access_token);
      tokenService.generateRefreshToken.mockResolvedValue(tokens.refresh_token);
      tokenService.generateSessionSecret.mockReturnValue(tokens.sessionSecret);
      sessionService.toResponse.mockReturnValue({ ...tokens, id: session.id });
      userService.toResponse.mockReturnValue({ id: user.id });

      const result = await service.signIn(
        { email: user.email, password: 'pass' },
        { ipAddress: '1.2.3.4', userAgent: 'Agent' },
      );

      expect(result).toHaveProperty('user');
      expect(result).toHaveProperty('session');
      expect(result.require_email_verification).toBe(false);
    });
  });

  // ---------- signUp ---------- //
  describe('signUp', () => {
    const baseInput: any = {
      email: 'test@test.com',
      password: '1234',
      organization_id: 'org1',
      role: 'admin',
      is_global_admin: false,
      global_admin_key: '',
      first_name: 'Test',
      last_name: 'User',
      avatar_url: null,
      metadata: null,
    };

    it('should throw if email exists', async () => {
      userService.existsByEmail.mockResolvedValue(true);
      await expect(
        service.signUp(baseInput, { ipAddress: '', userAgent: '' }, true, 'key'),
      ).rejects.toThrow(ConflictException);
    });

    it('should throw if no organization_id', async () => {
      userService.existsByEmail.mockResolvedValue(false);
      await expect(
        service.signUp(
          { ...baseInput, organization_id: undefined },
          { ipAddress: '', userAgent: '' },
          false,
          '',
        ),
      ).rejects.toThrow(ConflictException);
    });

    it('should throw if global admin key is invalid', async () => {
      userService.existsByEmail.mockResolvedValue(false);
      await expect(
        service.signUp(
          { ...baseInput, is_global_admin: true },
          { ipAddress: '', userAgent: '' },
          false,
          '',
        ),
      ).rejects.toThrow(ForbiddenException);
    });

    it('should create user, membership and assign role', async () => {
      userService.existsByEmail.mockResolvedValue(false);
      userService.createUser.mockResolvedValue({ id: 'user1' });
      sessionService.create.mockResolvedValue({ id: 'sess1' });
      organizationService.getOrganizationById.mockResolvedValue({ id: 'org1' });
      membershipService.createMembership.mockResolvedValue({ id: 'mem1' });
      userService.toResponse.mockReturnValue({ id: 'user1' });

      const result = await service.signUp(baseInput, { ipAddress: '', userAgent: '' }, true, '');

      expect(result.user).toEqual({ id: 'user1' });
      expect(dataSource.transaction).toHaveBeenCalled();
    });
  });

  // ---------- refreshToken ---------- //
  describe('refreshToken', () => {
    it('should throw if session is not found', async () => {
      tokenService.decodePayload.mockReturnValue({ sid: 'sess1' });
      sessionService.getActiveSessionById.mockResolvedValue(null);
      await expect(service.refreshToken({ refresh_token: 'x' })).rejects.toThrow(
        UnauthorizedException,
      );
    });

    it('should throw if token is invalid or expired', async () => {
      const session = {
        id: 'sess1',
        session_secret: 'sec',
        expires_at: new Date(Date.now() - 1000),
        user: { id: 'u', email: 'a' },
      };
      sessionService.getActiveSessionById.mockResolvedValue(session);
      tokenService.decodePayload.mockReturnValue({ sid: 'sess1' });
      tokenService.verifyRefreshToken.mockImplementation(() => {
        throw new Error();
      });

      await expect(service.refreshToken({ refresh_token: 'x' })).rejects.toThrow(
        UnauthorizedException,
      );
    });

    it('should return new tokens', async () => {
      const session = {
        id: 'sess1',
        session_secret: 'secret',
        expires_at: new Date(Date.now() + 1000),
        user: { id: 'u1', email: 'x', first_name: 'f', last_name: 'l', is_email_verified: true },
      } as any;

      tokenService.decodePayload.mockReturnValue({ sid: 'sess1', sub: 'u1' });
      sessionService.getActiveSessionById.mockResolvedValue(session);
      tokenService.verifyRefreshToken.mockResolvedValue(true);
      sessionService.verifyTokenHash.mockResolvedValue(true);
      membershipService.getMembershipAndOrg.mockResolvedValue({
        organization: { id: 'org', slug: 'org', domain: undefined },
        role: 'admin',
      });
      tokenService.generateAccessToken.mockResolvedValue('acc');
      tokenService.generateRefreshToken.mockResolvedValue('ref');
      tokenService.generateSessionSecret.mockReturnValue('secret');
      passwordService.hashPassword.mockResolvedValue('hashed');
      sessionService.toResponse.mockReturnValue({ id: 'sess1' });
      userService.toResponse.mockReturnValue({ id: 'u1' });
      emailVerificationService.createVerificationTokenEmail.mockResolvedValue({ token: 'tok' });
      emailService.getTemplateBySlug.mockReturnValue({});
      emailService.sendEmailWithTemplate.mockReturnValue({});

      const result = await service.refreshToken({ refresh_token: 'abc' });

      expect(result).toHaveProperty('user');
      expect(result).toHaveProperty('session');
    });
  });

  // ---------- logout ---------- //
  describe('logout', () => {
    it('should revoke session', async () => {
      sessionService.revokeSession.mockResolvedValue(true);
      const result = await service.logout('sess1');
      expect(result).toBe(true);
    });
  });
});
