import {
  BadRequestException,
  Body,
  Controller,
  NotFoundException,
  Post,
  Query,
  Req,
  UseGuards,
  UsePipes,
} from '@nestjs/common';
import { ZodValidationPipe } from 'nestjs-zod';

import { JwtAuthGuard } from '@/services/identity-ms/guards/jwt.guard';
import { UserService } from '../../user/services/user.service';
import { TokenService } from '../../token/services/token.service';
import { EmailVerificationService } from '../../../../email-ms/services/verification.service';
import { PasswordService } from '../services/password.service';

@UsePipes(ZodValidationPipe)
@Controller('password')
export class PasswordController {
  constructor(
    private readonly userService: UserService,
    private readonly tokenService: TokenService,
    private readonly emailVerifactionService: EmailVerificationService,
    private readonly passwordService: PasswordService,
  ) {}

  @Post('forgot-password')
  async forgotPassword(@Body('email') email: string) {
    const user = await this.userService.findByEmail(email);
    if (!user) throw new NotFoundException('User not found');

    const tokenExpiration = new Date(Date.now() + 60 * 60 * 1000);
    const token = await this.tokenService.generateToken(
      { user, expires_at: tokenExpiration },
      process.env.PASSWORD_RESET_SECRET,
      '1h',
    );

    const resetToken = await this.emailVerifactionService.createToken(
      user.id,
      token,
      tokenExpiration,
    );

    // ← aquí iría el envío de email real (emailService.sendPasswordReset)
    // await this.emailService.sendPasswordResetEmail(user.email, resetToken.token);

    return {
      message: 'Password reset email sent successfully',
      user: this.userService.toResponse(user),
    };
  }

  @Post('reset-password')
  async resetPassword(
    @Req() req,
    @Query('token') token: string,
    @Body('password') password: string,
  ) {
    const user = await this.userService.findById(req.user.sub);
    if (!user) throw new NotFoundException('User not found');

    const { token: resetToken } =
      await this.emailVerifactionService.getEmailVerificationToken(token);
    if (!resetToken) throw new NotFoundException('Invalid password reset token');

    if (resetToken.expires_at < new Date()) {
      throw new NotFoundException('Password reset token expired');
    }

    const hashedPassword = await this.passwordService.hashPassword(password);
    user.password_hash = hashedPassword;
    user.updated_at = new Date();

    await this.userService.updateUser(user);

    // Eliminar el token de restablecimiento de contraseña
    await this.emailVerifactionService.deleteToken(resetToken);

    return {
      message: 'Password reset successfully',
      user: this.userService.toResponse(user),
    };
  }

  @Post('change-password')
  @UseGuards(JwtAuthGuard)
  async changePassword(
    @Req() req,
    @Body('oldPassword') oldPassword: string,
    @Body('newPassword') newPassword: string,
  ) {
    const user = await this.userService.findById(req.user.sub);
    if (!user) throw new NotFoundException('User not found');

    const ok = await this.passwordService.checkPassword(user.password_hash, oldPassword);
    if (!ok) throw new BadRequestException('Current password incorrect');

    user.password_hash = await this.passwordService.hashPassword(newPassword);
    user.updated_at = new Date();

    await this.userService.updateUser(user);

    return {
      message: 'Password changed successfully',
      user: this.userService.toResponse(user),
    };
  }
}
