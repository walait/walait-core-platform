import { Test, TestingModule } from '@nestjs/testing';
import { PasswordService } from '../../password/password.service';
import { hash, verify } from 'argon2';

jest.mock('argon2', () => ({
  hash: jest.fn(),
  verify: jest.fn(),
}));

describe('PasswordService', () => {
  let service: PasswordService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [PasswordService],
    }).compile();

    service = module.get<PasswordService>(PasswordService);
  });

  afterEach(() => jest.clearAllMocks());

  describe('hashPassword', () => {
    it('should hash the password using argon2.hash', async () => {
      const plain = 'super-secret';
      (hash as jest.Mock).mockResolvedValue('hashed-value');

      const result = await service.hashPassword(plain);

      expect(hash).toHaveBeenCalledWith(plain);
      expect(result).toBe('hashed-value');
    });
  });

  describe('checkPassword', () => {
    it('should verify password without secret', async () => {
      (verify as jest.Mock).mockResolvedValue(true);

      const ok = await service.checkPassword('plain', 'hashed');

      expect(verify).toHaveBeenCalledWith('hashed', 'plain');
      expect(ok).toBe(true);
    });

    it('should verify password with secret (pepper)', async () => {
      (verify as jest.Mock).mockResolvedValue(true);

      await service.checkPassword('plain', 'hashed');

      expect(verify).toHaveBeenCalledWith('hashed', 'plain');
    });

    it('should return false when verification fails', async () => {
      (verify as jest.Mock).mockResolvedValue(false);

      const ok = await service.checkPassword('wrong', 'hashed');

      expect(ok).toBe(false);
    });
  });
});
