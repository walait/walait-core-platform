import { Test, TestingModule } from '@nestjs/testing';
import { UserController } from './user.controller';
import { UserService } from '../services/user.service';
import { PermissionService } from '@/services/access-ms/modules/permission/services/permission.service';
import { NotFoundException, ConflictException } from '@nestjs/common';
import { User } from '../models/user.entity';
import { TokenService } from '../../token/services/token.service';

describe('UserController', () => {
  let controller: UserController;
  let userService: jest.Mocked<UserService>;
  let permissionService: jest.Mocked<PermissionService>;

  const mockUser: User = {
    id: 'user-1',
    email: 'test@example.com',
    first_name: 'Test',
    last_name: 'User',
    password_hash: 'hashed',
    avatar_url: null,
    metadata: null,
    is_email_verified: false,
    created_at: undefined,
    updated_at: undefined,
    userRoles: [],
    is_deleted: false,
    is_active: false,
    is_suspended: false,
  };

  const req = {
    user: {
      sub: 'user-1',
      email: 'test@example.com',
    },
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [UserController],
      providers: [
        {
          provide: UserService,
          useValue: {
            findById: jest.fn(),
            updateUser: jest.fn(),
            deleteUser: jest.fn(),
            toResponse: jest.fn().mockReturnValue({ id: mockUser.id }),
          },
        },
        {
          provide: TokenService,
          useValue: {
            verifyAccessToken: jest.fn().mockResolvedValue(true),
            decodePayload: jest.fn().mockReturnValue({ sub: 'user-1' }),
          },
        },
        {
          provide: PermissionService,
          useValue: {
            canAccessOrOwnsResource: jest.fn(),
          },
        },
      ],
    }).compile();

    controller = module.get(UserController);
    userService = module.get(UserService);
    permissionService = module.get(PermissionService);
    jest.clearAllMocks();
  });

  describe('getProfile', () => {
    it('should return current user from request', async () => {
      const result = await controller.getProfile(req as any);
      expect(result).toEqual(req.user);
    });
  });

  describe('updateProfile', () => {
    it('should update user profile successfully', async () => {
      const updateData = {
        email: mockUser.email,
        first_name: 'New Name',
        last_name: 'New Last Name',
        password_hash: mockUser.password_hash,
        avatar_url: 'https://example.com/avatar.png',
        metadata: { job: 'dev' },
        ...mockUser,
      };

      userService.findById.mockResolvedValue({ ...mockUser });
      userService.updateUser.mockResolvedValue({ ...mockUser, ...updateData });
      const result = await controller.updateProfile(req as any, updateData as any);

      expect(result).toEqual({
        message: 'Profile updated successfully',
        user: { id: mockUser.id },
      });
    });

    it('should throw NotFoundException if user not found', async () => {
      userService.findById.mockResolvedValue(null);

      await expect(controller.updateProfile(req as any, {} as any)).rejects.toThrow(
        NotFoundException,
      );
    });

    it('should throw ConflictException if email is changed', async () => {
      userService.findById.mockResolvedValue(mockUser);

      await expect(
        controller.updateProfile(req as any, { email: 'new@example.com' } as any),
      ).rejects.toThrow(ConflictException);
    });

    it('should throw ConflictException if password is changed', async () => {
      userService.findById.mockResolvedValue(mockUser);

      await expect(
        controller.updateProfile(
          req as any,
          {
            password: 'new-hash',
            email: mockUser.email,
          } as any,
        ),
      ).rejects.toThrow(ConflictException);
    });
  });

  describe('deleteProfile', () => {
    it('should delete user successfully', async () => {
      userService.findById.mockResolvedValue(mockUser);
      const result = await controller.deleteProfile(req as any, mockUser.id);
      expect(permissionService.canAccessOrOwnsResource).toHaveBeenCalledWith(
        mockUser,
        'delete:profile',
        mockUser.id,
        req.user.sub,
      );

      expect(result).toEqual({
        message: 'Profile deleted successfully',
        user: { id: mockUser.id },
      });
    });

    it('should throw NotFoundException if user not found', async () => {
      userService.findById.mockResolvedValue(null);

      await expect(controller.deleteProfile(req as any, 'nonexistent-id')).rejects.toThrow(
        NotFoundException,
      );
    });
  });
});
