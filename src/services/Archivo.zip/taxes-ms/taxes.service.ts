import { Injectable, Inject, Logger } from '@nestjs/common';
import { ITaxProvider } from './interfaces/provider.interface';
import { Payment } from './interfaces/payment.interface';
import { TaxTicket } from './interfaces/ticket.interface';
import { TAX_PROVIDERS } from './taxes.const';

@Injectable()
export class TaxesService {
  private readonly logger = new Logger(TaxesService.name);

  constructor(
    @Inject(TAX_PROVIDERS)
    private readonly providers: ITaxProvider[],
  ) {}

  /**
   * Procesa un pago utilizando el provider adecuado según el país.
   */
  async processPayment(payment: Payment): Promise<TaxTicket> {
    const provider = this.providers.find((p) => p.canHandle(payment.countryIso));

    if (!provider) {
      throw new Error(`No tax provider found for country ${payment.countryIso}`);
    }

    this.logger.log(`Delegando pago ${payment.id} a ${provider.constructor.name}`);
    return provider.process(payment);
  }
}
