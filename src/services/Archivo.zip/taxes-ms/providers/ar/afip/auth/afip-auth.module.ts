import { Module } from '@nestjs/common';
import { AfipAuthService } from './afip-auth.service';
import { WsaaModule } from './wsaa/wsaa.module';

@Module({
  imports: [WsaaModule],
  providers: [AfipAuthService],
  exports: [AfipAuthService],
})
export class AfipAuthModule {}
