import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { TicketBuilder } from './ticket.builder';
import { TicketSigner } from './ticket.signer';
import { WsaaSoapClient } from './wsaa.client';
import { TokenStore } from './token.store';
import { randomUUID } from 'crypto';
import { tmpdir } from 'node:os';
import { writeFile, rm } from 'fs/promises';
import * as path from 'path';

@Injectable()
export class WsaaService {
  private readonly logger = new Logger(WsaaService.name);

  private readonly wsdlPath: string;
  private readonly endpointUrl: string;

  constructor(
    private readonly config: ConfigService,
    private readonly builder: TicketBuilder,
    private readonly signer: TicketSigner,
    private readonly client: WsaaSoapClient,
    private readonly store: TokenStore,
  ) {
    this.wsdlPath = this.config.getOrThrow<string>('WSAA_WSDL');
    this.endpointUrl = this.config.getOrThrow<string>('WSAA_URL');
  }

  /**
   * Devuelve un TA válido desde cache o renovado.
   */
  async getAuthorizationTicket(
    service: string,
    certData: { cert: string; key: string; passphrase?: string },
  ): Promise<string> {
    this.validatePEM(certData.cert, 'cert');
    this.validatePEM(certData.key, 'key');

    const { cert, key, passphrase = '' } = certData;

    const cached = await this.store.getValid(service, cert, key);
    if (cached) return cached;

    const traPath = await this.builder.build(service);

    const tmpId = randomUUID();
    const certPath = path.join(tmpdir(), `afip-cert-${tmpId}.crt`);
    const keyPath = path.join(tmpdir(), `afip-key-${tmpId}.key`);

    await writeFile(certPath, cert);
    await writeFile(keyPath, key);

    try {
      const cms = await this.signer.sign(traPath, certPath, keyPath, passphrase);
      const taXml = await this.client.callLoginCms(cms, this.wsdlPath, this.endpointUrl);
      await this.store.save(service, cert, key, taXml);
      return taXml;
    } finally {
      await Promise.allSettled([rm(certPath, { force: true }), rm(keyPath, { force: true })]);
    }
  }

  validatePEM(content: string, label: string): void {
    if (!content.includes('-----BEGIN') || !content.includes('-----END')) {
      throw new Error(`El archivo ${label} no tiene formato PEM válido`);
    }
  }
}
