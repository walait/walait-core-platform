import { Inject, Injectable } from '@nestjs/common';
import Redis from 'ioredis';
import { parseStringPromise } from 'xml2js';
import { createHash } from 'crypto';
import { REDIS_CLIENT } from '@/shared/shared.module';

@Injectable()
export class TokenStore {
  constructor(@Inject(REDIS_CLIENT) private readonly redis: Redis) {}

  private getCacheKey(service: string, cert: string, key: string): string {
    const hash = createHash('sha256')
      .update(cert + key + service)
      .digest('hex');
    return `afip:ta:${hash}`;
  }

  async getValid(service: string, cert: string, key: string): Promise<string | null> {
    const redisKey = this.getCacheKey(service, cert, key);
    const raw = await this.redis.get(redisKey);
    if (!raw) return null;

    const parsed = await parseStringPromise(raw);
    const exp = parsed?.loginTicketResponse?.header?.[0]?.expirationTime?.[0];
    if (!exp) return null;

    const expiration = new Date(exp);
    return expiration > new Date() ? raw : null;
  }

  async save(service: string, cert: string, key: string, taXml: string): Promise<void> {
    const redisKey = this.getCacheKey(service, cert, key);
    const parsed = await parseStringPromise(taXml);
    const exp: string = parsed?.loginTicketResponse?.header?.[0]?.expirationTime?.[0];
    if (!exp) throw new Error('TA sin expirationTime');

    const expiration = new Date(exp);
    const ttl = Math.floor((expiration.getTime() - Date.now()) / 1000);
    await this.redis.set(redisKey, taXml, 'EX', ttl);
  }
}
