import { Module } from '@nestjs/common';
import { WsaaService } from './wsaa.service';
import { TicketBuilder } from './ticket.builder';
import { TicketSigner } from './ticket.signer';
import { WsaaSoapClient } from './wsaa.client';
import { TokenStore } from './token.store';
import { SharedModule } from '@/shared/shared.module';

@Module({
  providers: [WsaaService, TicketBuilder, TicketSigner, WsaaSoapClient, TokenStore],
  imports: [SharedModule], // ✅ agregá esto
  exports: [WsaaService],
})
export class WsaaModule {}
