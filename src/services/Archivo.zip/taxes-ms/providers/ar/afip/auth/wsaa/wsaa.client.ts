import { Injectable, Logger } from '@nestjs/common';
import * as soap from 'soap';
import { writeFile } from 'fs/promises';

@Injectable()
export class WsaaSoapClient {
  private readonly logger = new Logger(WsaaSoapClient.name);

  /**
   * Invoca loginCms pasando el CMS firmado y devuelve el TA (XML)
   */
  async callLoginCms(cms: string, wsdlPath: string, endpointUrl: string): Promise<string> {
    this.logger.log('Creando cliente SOAP de AFIP');

    const client = await soap.createClientAsync(wsdlPath, {
      endpoint: endpointUrl,
      wsdl_headers: {},
      wsdl_options: {},
    });

    this.logger.debug('Enviando loginCms...');
    const [response] = await client.loginCmsAsync({ in0: cms });

    // Guarda request/response en disco (solo para debug/auditoría)
    await writeFile('request-loginCms.xml', client.lastRequest);
    await writeFile('response-loginCms.xml', client.lastResponse);

    this.logger.log('TA recibido correctamente desde AFIP');

    return response.loginCmsReturn;
  }
}
