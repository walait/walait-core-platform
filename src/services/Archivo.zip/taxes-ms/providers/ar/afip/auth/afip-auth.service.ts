import { Injectable } from '@nestjs/common';
import { WsaaService } from './wsaa/wsaa.service';
import { parseStringPromise } from 'xml2js';

@Injectable()
export class AfipAuthService {
  constructor(private readonly wsaa: WsaaService) {}

  /**
   * Devuelve el TA parseado para un servicio AFIP (ej: wsfe)
   */
  async getTokenAndSign(
    service: string,
    certData: {
      cert: string;
      key: string;
      passphrase?: string;
    },
  ): Promise<{
    token: string;
    sign: string;
    expirationTime: string;
    rawXml: string;
  }> {
    const taXml = await this.wsaa.getAuthorizationTicket(service, certData);
    const parsed = await parseStringPromise(taXml);

    const token = parsed?.loginTicketResponse?.credentials?.[0]?.token?.[0];
    const sign = parsed?.loginTicketResponse?.credentials?.[0]?.sign?.[0];
    const expirationTime = parsed?.loginTicketResponse?.header?.[0]?.expirationTime?.[0];

    if (!token || !sign || !expirationTime) {
      throw new Error('Token o firma inválidos en TA');
    }

    return { token, sign, expirationTime, rawXml: taXml };
  }
}
