import { Injectable, Logger } from '@nestjs/common';
import { execFileSync } from 'child_process';
import { readFile, unlink } from 'fs/promises';
import * as path from 'node:path';

@Injectable()
export class TicketSigner {
  private readonly logger = new Logger(TicketSigner.name);

  /**
   * Firma digitalmente el archivo TRA y devuelve el CMS en Base64
   * @param traPath - Ruta al archivo TRA.xml generado
   * @param certPath - Ruta al archivo .crt
   * @param keyPath - Ruta al archivo .key
   * @param passphrase - Passphrase del archivo .key (si existe)
   */
  async sign(
    traPath: string,
    certPath: string,
    keyPath: string,
    passphrase: string,
  ): Promise<string> {
    const tmpPath = path.resolve('TRA.tmp');

    this.logger.debug('Firmando TRA usando openssl');

    execFileSync('openssl', [
      'pkcs7',
      '-sign',
      '-in',
      traPath,
      '-out',
      tmpPath,
      '-signer',
      certPath,
      '-inkey',
      keyPath,
      ...(passphrase ? ['-passin', `pass:${passphrase}`] : []),
      '-outform',
      'PEM',
      '-nodetach',
    ]);

    const content = await readFile(tmpPath, 'utf8');
    await unlink(tmpPath);

    const lines = content.split('\n');
    const base64 = lines.slice(4).join('').replace(/\r?\n/g, '');

    return base64;
  }
}
