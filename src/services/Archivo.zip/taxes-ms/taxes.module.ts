import { Module, Global } from '@nestjs/common';
import { TaxesService } from './taxes.service';
import { ArTaxesModule } from './providers/ar/ar-taxes.module';

@Global()
@Module({
  imports: [ArTaxesModule], // ← MUY IMPORTANTE
  providers: [TaxesService],
  exports: [TaxesService],
})
export class TaxesModule {}
